// utils/zones.js
export const COVERAGE = {
  europe: true,
  usa: true,
  other: false
};
