// dbUtils.js — redirection de compatibilité
export { saveExtractionToMongo } from "./extractionStore.js";
